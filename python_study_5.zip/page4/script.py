from food import Food
from drink import Drink

food1 = Food('Roti Lapis', 5)

# Tetapkan variable calorie_count milik food1 ke 330
food1.calorie_count=330

# Panggil method calorie_info dari food1
food1.calorie_info()
