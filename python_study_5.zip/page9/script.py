from food import Food
from drink import Drink

food1 = Food('Roti Lapis', 5, 330)
print(food1.info())

# Tambahakan argument ke Drink()
drink1 = Drink('Kopi', 3, 180)

# Hapus satu baris di bawah

print(drink1.info())
